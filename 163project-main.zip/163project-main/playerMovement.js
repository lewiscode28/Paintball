AFRAME.registerComponent("player-movement", {
  init: function () {
    this.walk();
  },
  walk: function () {
    window.addEventListener("keydown", (e) => {
    //add the code to play sound as per selection of arrow keys for movement




    });
  },
});

